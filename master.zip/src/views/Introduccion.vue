<template lang="pug">
.curso-main-container.introduccion
  BannerInterno(subTitulo="Introducción")
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5
    .row.mb-5 
      .col-lg-8.mb-3.mb-lg-0 
        p(data-aos="fade-down") En todos los rincones del mundo, la educación es reconocida como un derecho humano esencial. Sin embargo, este derecho no existe por sí solo: está respaldado por normas, leyes y acuerdos que le dan forma y lo hacen exigible. Comprender esos fundamentos legales permite actuar con mayor responsabilidad en los escenarios educativos y tomar decisiones que respeten la dignidad y los derechos de niñas, niños y jóvenes.
        .bg-color-1.p-4(data-aos="fade-up") 
          p(data-aos="fade-down").mb-0 Esta unidad invita a explorar los aspectos legales que sustentan la educación, partiendo de una mirada internacional hasta llegar al contexto colombiano. Se estudia la Declaración Universal de los Derechos Humanos, las entidades internacionales que orientan el derecho a la educación, la Constitución Política de Colombia y el Decreto 1075 del 2015, también conocido como Decreto Único Reglamentario del Sector Educación. Además, se propone analizar la pirámide de Kelsen, una herramienta que permite comprender la jerarquía normativa que organiza el marco legal educativo. 
      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/1.png", data-aos="zoom-in") 
                     


    .bg-full-width.bg-color-2.p-4(data-aos="fade-left")
      .row
        .col-lg-auto
          img.img-a.img-t(src="@/assets/curso/temas/2.svg")
        .col-lg.j1
          p.mb-0 El propósito central es brindar elementos conceptuales y prácticos que permitan identificar, interpretar y aplicar la legislación educativa en diferentes contextos. Al finalizar la unidad, se espera que se reconozca la importancia del marco legal en la protección de los derechos de la infancia, y que se puedan desarrollar argumentos sólidos y éticos frente a situaciones reales en la gestión educativa.
</template>
