<template lang="pug">
  .curso-main-container.creditos-vista
    BannerInterno(subTitulo="SÍNTESIS")
    .container.tarjeta.tarjeta--blanca.p-4.p-md-5
      p(data-aos="fade-up").mb-5 La unidad aborda los fundamentos legales que respaldan el derecho a la educación, destacando su relevancia en la protección y promoción de los derechos de niños, niñas y jóvenes. Se presenta un recorrido desde los marcos normativos internacionales, hasta las disposiciones nacionales que rigen el sistema educativo colombiano, permitiendo así una comprensión amplia y contextualizada.

      .row.justify-content-center
        .col-lg-12.mb-5
          figure.bg-color-sintesis.p-5.brounded
            img(src='@/assets/curso/sintesis.svg', alt='', data-aos="zoom-in")
</template>
